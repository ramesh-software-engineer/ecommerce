from django.apps import AppConfig


class BoardsConfig(AppConfig):
    name = 'apps'
