from django.shortcuts import render
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse
from django.http import HttpResponseNotFound
from django.template.response import TemplateResponse


#from .models import apps
from .models import Catgory,Product 
from .basket import Basket

def home(request): 

    activate = '/'

    metatitle = 'ShopR - eCommerce'   
    return render(request, 'pages/home.html', {'metatitle': metatitle, 'activate' : activate})

def category(request): 

    activate = 'category'  
    categories = Catgory.objects.order_by('name').all() 
    metatitle = 'Shop' 
   
    return render(request, 'pages/shop.html', {'metatitle': metatitle,'activate' : activate, "categories": categories}) 
 
 
 

def categories(request, cat_id):   

    activate = 'category'   
    metatitle = 'Shop' 
    categories = Catgory.objects.order_by('name').all() 
    productslist = Product.objects.filter(category = cat_id)  


    page = request.GET.get('page', 1)

    paginator = Paginator(productslist, 3)
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        products = paginator.page(1)
    except EmptyPage:
        products = paginator.page(paginator.num_pages) 
    #return HttpResponse(products.query)
 
    category = Catgory.objects.filter(id = cat_id).first()  
    return render(request, 'pages/category.html', {'metatitle': metatitle, 'activate' : activate,"categories": categories,"products": products, "category" : category})

  

def about(request):

    activate = 'about'
    metatitle = 'About us'  
    return render(request, 'pages/about.html', {'metatitle': metatitle,'activate' : activate})


def contact(request):  

    activate = 'contact'
    metatitle = 'Contact Us' 

    return render(request, 'pages/contact.html', {'metatitle': metatitle, 'activate' : activate })

def login(request):  

    metatitle = 'Login' 

    return render(request, 'pages/login.html', {'metatitle': metatitle })

def register(request):  

    metatitle = 'Register' 

    return render(request, 'pages/register.html', {'metatitle': metatitle })



