class Basket(object):
	"""docstring for ClassName"""

	items = '';
	totalQuantity = 0
	totalPrice = 0


	def __init__(self, oldBasket):

		if oldBasket:
			self.items = oldCart.items
			self.totalPrice = oldCart.totalPrice
			self.otalQuantity = oldCart.totalQuantity


	def additem(item, id):

		storedItem = {
						'qty': 0, 
						'price': item.price,
						'item': item
					}

		storedItem['qty'] += 1
		storedItem['price']= item.price * storedItem['qty']
		self.items[id] = storedItem
		self.totalQuantity += 1
		self.totalPrice += item.price;
		 

	 