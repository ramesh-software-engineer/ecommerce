from django import template  
from apps.models import Basket  
from django.http import HttpResponse   

register = template.Library()



def basket_button(request, sessid):

    basket = request.session.get('sessid') 
    cartitems = Basket(basket)

    if  format(sessid) in format(cartitems.items): 
        id = 0
        label = " Remove from basket"
    else:
        id = 1
        label = " Add to basket" 

    response = '<a href="javascript:void(0)" class="add_to_basket btn-common"' 
    response += 'rel="'
    response += format(sessid)+  "_" + format(id) 
    response += '"><i class="icon-basket-loaded"></i>  Add to basket</a>'
 
    return response; 


@register.simple_tag(takes_context=True)
def activeButton(context, sessid):   

    request = context['request'] 
    return basket_button(request, sessid); 