from django.db import models
from django.contrib.auth.models import User
 

class Catgory(models.Model):
	#id = models.IntegerField(unique=True, db_column='id') # Field name made lowercase.
	name = models.CharField(max_length=50)

	#publication_date = models.DateField(null=True)
	#author = models.CharField(max_length=30, blank=True)
	#price = models.DecimalField(max_digits=5, decimal_places=2)
	#pages = models.IntegerField(blank=True, null=True)
	#book_type = models.PositiveSmallIntegerField(choices=BOOK_TYPES)
 
	class Meta:
			db_table = 'category' 
			
	def __str__(self):
		return self.name



class Product(models.Model):
	"""docstring for ClassName"""
	#id = models.IntegerField(unique=True, db_column='ID') # Field name made lowercase.
	name = models.CharField(max_length=50)
	price = models.DecimalField(max_digits=5, decimal_places=2)
	description = models.CharField(max_length=355, blank=True) 
	image = models.CharField(max_length=355, blank=True) 
	category = models.IntegerField(db_column='category') # Field name made lowercase.
	

	class Meta:
		db_table = 'products' 


class Basket:
	"""docstring for ClassName"""

	items = None
	totalQuantity = 0
	totalPrice = 0


	def __init__(self, oldBasket):

		if oldBasket:
			self.items = oldCart.items
			self.totalPrice = oldCart.totalPrice
			self.otalQuantity = oldCart.totalQuantity


	def additem(item, id):

		storedItem = {
						'qty': 0, 
						'price': item.price,
						'item': item
					}

		storedItem['qty'] += 1
		storedItem['price']= item.price * storedItem['qty']
		self.items[id] = storedItem
		self.totalQuantity += 1
		self.totalPrice += item.price;

	

		 
			
		



 