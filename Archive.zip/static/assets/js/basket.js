//************ Add to basket start ************//
$(document).ready(function(){

 
	 
	
	function refreshbasket() {
		
		$.get(site_url+'ajax/view-basket', function(resp){ 
           
            spareparts_count = resp.spareparts_count; 
            if(resp.status == "updated") {
                $('#saprepart_count').html(spareparts_count); 
				$('#main-basket').html(resp.html_view);
            }
             
        }, 'json');
		
		
	}
	 
	 
	$(document).on('click', '.add_to_basket', function(){  

	var token = $("#token").val();
	 var totalQty = 0;
        var trigger = $(this);
            var param = trigger.attr("rel");
            alert(param);
            var item = param.split("_");
            $.post(site_url+'ajax/add-to-basket', { id : item[0], job : item[1], _token : token }, function(data) {
                var totalQty = data.qty; 
                var new_id = item[0] + '_' + data.job;
                if (data.job != item[1]) {
                    if (data.job == 0) { 
                        trigger.attr("rel", new_id);
                        trigger.html("<i style='color:#fff' class='fa fa-shopping-cart'></i> Remove from basket");
                        trigger.addClass("btn-link"); 
                        trigger.removeClass("basket_expand");
                    } else { 
                        trigger.attr("rel", new_id);
                        trigger.html("<i style='color:#fff' class='fa fa-shopping-cart'></i> Add to basket");
                        trigger.removeClass("btn-link");
                        trigger.addClass("basket_expand");
                    }
                  $("#saprepart_count").html(totalQty);   
                }
            }, 'json');
    });
	 
	
	
	
	$(document).on('click', '.remove_from_basket', function(){ 
         var product_id = $(this).data('productid');  
		 var saprepart_count = 0;
		$("#rem_to_basket_"+product_id).hide();
		$("#show_to_basket_"+product_id).show();
        $.get(site_url+"ajax/remove-to-basket/"+product_id, function(resp){   
		
            spareparts_count = resp.spareparts_count; 
            if(resp.status == "removed") {
				$("#rem_to_basket_"+product_id).hide();
				$("#show_to_basket_"+product_id).show();
				refreshbasket();
                
            }
             
        }, 'json');
    });
	 
	 
	 $(document).on('click', '.QuantityPlus', function(){ 
	 
        var quantitiy =0;
		var product_id = $(this).data('productid');  
		var quantity = parseInt($('#quantity_'+product_id).val());
		var TotalQuant =  $('#quantity').val(quantity + 1);   
		var saprepart_count = 0;  
		$("#plus-hide-spin-"+product_id).hide();
		$("#plus-show-spin-"+product_id).show();
        $.get(site_url+"ajax/add-to-qty/"+product_id, function(resp){   
		
            spareparts_count = resp.spareparts_count; 
            if(resp.status == "updated") { 
				refreshbasket();
                 
            }
             
        }, 'json');
    });
	 
	 
 

	 
	 $(document).on('click', '.QuantityMinus', function(){  
        var quantitiy =0;
		var product_id = $(this).data('productid');  
		var quantity = parseInt($('#quantity_'+product_id).val()); 
		var saprepart_count = 0; 
		$("#minus-hide-spin-"+product_id).hide();
		$("#minus-show-spin-"+product_id).show();
		if (!isNaN(quantity) && quantity > 0) {
             $.get(site_url+"ajax/remove-to-qty/"+product_id, function(resp){   
			
				spareparts_count = resp.spareparts_count; 
				if(resp.status == "updated") { 
					refreshbasket();
					$("#hide-spin-"+product_id).show();
					$("#show-spin-"+product_id).hide();
					
				}
				 
			}, 'json'); 
        } else {
			refreshbasket();
			$("#hide-spin-"+product_id).show();
			$("#show-spin-"+product_id).hide();
		}
			
    });  
	
	
	
	
	//payment gateway process
	
	 $(document).on('click', '.payment_submit', function(){   
	 
		if (!$('input[name=delivery_location]:checked').val() ) {    
			$("#errormessage").show().html("<span style='color:red;'>You have to select location!</span>"); 
			setTimeout(function(){ $('#errormessage').fadeOut() }, 3000);
		} else {
			$("#errormessage").empty(); 
		}
	 
        $("#payment_form").validate({ 
            submitHandler: function(){
                var formData = $("#payment_form").serialize(); 
				$(".payment-hide").hide();
				$(".payment-show").show();	
                $.post(site_url+'ajax/payment_gateway', formData, function(resp){
					$("#payment_form").hide();  
                    if(resp.status == 'success') {
						 $("#payment_form").hide();
                        $(".show_response").show().html("<div class='alert alert-success'>"+resp.message+"</div>");  
						refreshbasket();
						setInterval(function() {
						  window.location.reload();
						}, 1000); 
                    } 
                }, 'json')
                .fail(function() {
					$(".payment-hide").show();
					$(".payment-show").hide();		
                    alert( "error occured, please try again" );
                });
            }
        });
    });
	
	
		
	 
	
		$(document).on('click', '.customer_submit', function(){    
		
		 
		$('input[type="file"]').change(function () { 
			var ext = this.value.match(/\.(.+)$/)[1];
			switch (ext) {
				case 'jpg':
				case 'jpeg':
				case 'png':
				case 'gif':
					$('#product_image').attr('disabled', false);
					$("#valid_image").empty(); 
					break;
				default:
					$("#valid_image").show().html("<p style='color:red;padding: 2px 0px 17px;line-height: 0;text-align: left;'>This is not an image file!</p>"); 
						setTimeout(function(){ $('#valid_image').fadeOut() }, 3000);
					this.value = '';
			}
		});
		
	 
	  
        $("#sparepart_customer_details").validate({ 
            submitHandler: function(){
               // var formData = $("#sparepart_customer_details").serialize(); 
				$(".customer-hide").hide();
				$(".customer-show").show();	 
				 var formData = new FormData($("#sparepart_customer_details")[0]);
				 
				 
				 $.ajax({  
						url: site_url+'ajax/request_sparepart', 
						type: "POST",           
						data: formData,  
						cache: false,
						contentType: false,
						processData: false,       
						dataType: "json",
						success: function(resp) {  
							if(resp.status == 'success') { 
								$("#sparepart_customer_details").hide(); 
									$(".show_response").show().html("<div class='alert alert-success'>"+resp.message+"</div>"); 
									$("form#sparepart_customer_details")[0].reset();
								} 
								  
							  //window.location.reload();
									  
								
						},
						error: function() {
								$(".customer-hide").show();
								$(".customer-show").hide();		
								alert( "error occured, please try again" );
							} 
					});  
			   
            } 
        });
    });
	

	
	
	
	});
	
	//************ Add to basket end  ************//
	
