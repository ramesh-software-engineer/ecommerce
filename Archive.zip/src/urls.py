from django.conf.urls import include, url
from django.contrib import admin


from apps import views

urlpatterns = [


	#front sit url


    url(r'^$', views.home, name='home'),
    url(r'^category/$', views.category, name='category'),  
    url(r'^about/$', views.about, name='about'),
    url(r'^contact/$', views.contact, name='contact'),
    url(r'^login/$', views.login, name='login'),
    url(r'^register/$', views.register, name='register'),

    #category id in url 
    #url(r'^categories/(?:(?P<cat_id>[1-9]+)/)?$', views.categories, name = 'categories'),   
    url(r'^categories/id/(\d+)/', views.categories, name = 'categories'),



 
    url(r'^admin/', admin.site.urls),
]
